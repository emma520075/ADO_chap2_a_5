"""
/******************************************************************************
 * Nom        : Chap_2_ex_2.3.py
 * Role       : Convertir un entier en chiffres romains (jusqu'a 3999)
 * Auteur     : Emma BARETS
 * Version    : Version finale du 14/12/2025
 * Licence    : Realise dans le cadre du cours Architecture des ordinateurs
 * Dependances : Aucun module externe requis
 * Usage      : Entrer un entier et obtenir son ecriture en chiffres romains
 ******************************************************************************/
"""

def entier_vers_romain(nombre):
    """
    Convertit un entier en chiffre romain.
    """

    # Verification que le nombre est strictement positif
    if nombre <= 0:
        print("La numeration romaine ne permet pas de representer 0 ou les nombres negatifs.")
        return None

    # Verification de la limite de la numeration romaine classique
    # Par convention, les nombres superieurs a 3999 ne sont pas representes
    if nombre > 3999:
        print("La numeration romaine standard ne supporte pas les nombres > 3999")
        return None

    # Liste des symboles romains et de leur valeur associee
    # On inclut les cas particuliers (CM, CD, XC, XL, IX, IV) 
    romains = [
        ('M', 1000), ('CM', 900), ('D', 500), ('CD', 400),
        ('C', 100), ('XC', 90), ('L', 50), ('XL', 40),
        ('X', 10), ('IX', 9), ('V', 5), ('IV', 4), ('I', 1)
    ]

    # Chaine vide qui contiendra progressivement le resultat final
    resultat = ""

    # Parcours de chaque symbole romain et de sa valeur associee
    for symbole, valeur in romains:

        # Tant que le nombre restant est superieur ou egal
        # a la valeur du symbole courant
        while nombre >= valeur:

            # Ajout du symbole romain au resultat
            resultat += symbole

            # Soustraction de la valeur utilisee
            nombre -= valeur

    # Retour du nombre converti en chiffres romains
    return resultat


# Test du programme

# Demande a l'utilisateur de saisir un entier
nombre = int(input("Entrez un entier : "))

# Appel de la fonction de conversion
romain = entier_vers_romain(nombre)

# Verification que la conversion a fonctionne
if romain is not None:
    # Affichage du resultat final
    print(f"{nombre} en chiffres romains : {romain}")

else:
    # Affichage d'un message d'erreur si la conversion est impossible
    print("Conversion impossible.")