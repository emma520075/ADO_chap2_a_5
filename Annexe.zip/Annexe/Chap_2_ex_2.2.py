"""
/******************************************************************************
 * Nom        : Chap_2_ex_2.2.py
 * Role       : Convertir deux nombres romains en entiers, verifier leur
 *              validite et afficher leur somme en base 10 et en chiffres romains
 * Auteur     : Emma BARETS
 * Version    : V2 du 14/12/2025
 * Licence    : Realise dans le cadre du cours Architecture des ordinateurs
 * Dependances : Aucun module externe requis
 * Usage      : Entrer deux nombres romains et afficher leur somme en base 10
 *              et en chiffres romains via la fonction de l'exercice 2.3
 ******************************************************************************/
"""
# Exercice 2.2 (Bonus)

def romain_vers_entier(romain):
    """
    Convertit un chiffre romain en entier.
    Applique les regles classiques :
    - Pas plus de 3 repetitions consecutives pour I, X, C, M
    - V, L, D ne sont jamais repetes
    - Limite de 3999 pour le resultat
    """
    # Conversion en majuscules 
    romain = romain.upper()

    # Dictionnaire contenant la valeur de chaque symbole romain (majuscules uniquement grace a .upper())
    valeurs = {
        'I':1, 'V':5, 'X':10, 'L':50, 'C':100, 'D':500, 'M':1000
    }

    # Symboles autorises a etre repetes (maximum 3 fois consecutives)
    # V, L, D sont absents car ils ne peuvent jamais etre repetes
    repetables = {'I', 'X', 'C', 'M'}

    compteur = 1  # Compteur de repetitions consecutives, initialise a 1 car le premier symbole compte deja
    total = 0     # Accumulateur de la valeur finale en base 10
    i = 0         # Indice de parcours de la chaine

    # Parcours de chaque symbole du nombre romain
    while i < len(romain):
        lettre = romain[i]  # Symbole courant

        # Verification que le caractere est bien un symbole romain valide
        if lettre not in valeurs:
            print(f"Erreur : symbole invalide detecte : {lettre}")
            return None

        # Detection des repetitions consecutives
        if i > 0 and romain[i] == romain[i-1]:
            compteur += 1
            # Symboles repetables : limite a 3 fois consecutives
            if lettre in repetables and compteur > 3:
                print(f"Erreur : le symbole {lettre} ne peut pas etre repete plus de 3 fois consecutivement.")
                return None
            # Symboles non repetables (V, L, D) : aucune repetition autorisee
            elif lettre not in repetables:
                print(f"Erreur : le symbole {lettre} ne peut pas etre repete.")
                return None
        else:
            compteur = 1  # Reinitialisation du compteur si le symbole change

        # Verification que le total ne depasse pas 3999
        if total > 3999:
            print("Erreur : la numeration romaine standard ne supporte pas les nombres > 3999.")
            return None

        # Cas soustractif : le symbole courant est plus petit que le suivant
        # On verifie d'abord que le symbole suivant existe pour eviter un IndexError
        if i + 1 < len(romain) and valeurs[lettre] < valeurs[romain[i + 1]]:
            total += valeurs[romain[i + 1]] - valeurs[lettre]  # Ex : IV = 5 - 1 = 4
            i += 2  # On saute les deux symboles utilises ensemble
        # Cas additif : le symbole courant est superieur ou egal au suivant
        else:
            total += valeurs[lettre]
            i += 1  # On passe au symbole suivant

    return total  # Valeur entiere en base 10

# On utilise la fonction de l'exercice 2.3

def entier_vers_romain(nombre):

    if nombre > 3999:
        print("La numeration romaine standard ne supporte pas les nombres > 3999")
        return None

    # Liste des symboles romains et leur valeur associee (du plus grand au plus petit)
    romains = [
        ('M',1000), ('CM',900), ('D',500), ('CD',400),
        ('C',100), ('XC',90), ('L',50), ('XL',40),
        ('X',10), ('IX',9), ('V',5), ('IV',4), ('I',1)
    ]
    
    resultat = ""  # Chaine pour la conversion finale

    # Parcours de chaque symbole et de sa valeur
    for symbole, valeur in romains:
        count = 0  # Compteur pour limiter les repetitions

        # Boucle tant que le nombre reste >= valeur et que la repetition est autorisee
        while nombre >= valeur and (
              (symbole in ['I','X','C','M'] and count < 3) or
              (symbole in ['V','L','D'] and count < 1) or
              (symbole in ['CM','CD','XC','XL','IX','IV'])  # symboles composes sans limite
        ):
            resultat += symbole
            nombre -= valeur
            count += 1

    return resultat  # Retourne le chiffre romain

# Saisie et conversion en majuscules directement sur l'input
romain1 = input("Entrez le premier nombre romain : ").upper()
romain2 = input("Entrez le second nombre romain : ").upper()

# Conversion de chaque nombre romain en entier
entier1 = romain_vers_entier(romain1)
entier2 = romain_vers_entier(romain2)

# Verification que les deux conversions ont reussi avant de calculer
if entier1 is not None and entier2 is not None:
    somme = entier1 + entier2
    print(f"La somme en base 10 est : {somme}")
    # Appel de la fonction de l'exercice 2.3 (voir section suivante)
    romain_resultat = entier_vers_romain(somme)
    print(f"La somme de {romain1} et {romain2} en chiffres romains est : {romain_resultat}")
else:
    print("Erreur lors de la conversion des nombres romains. Impossible de faire l'addition.")