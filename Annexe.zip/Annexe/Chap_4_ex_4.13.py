"""
/******************************************************************************
 * Nom        : Chap_4_ex_4.13.py
 * Rôle       : Multiplie deux nombres flottants et affiche le résultat 
 *              normalisé en notation scientifique
 * Auteur     : Emma BARETS
 * Version    : Version finale du 02/02/2026
 * Licence    : Réalisé dans le cadre du cours Architecture des ordinateurs
 * Dépendances : Aucun
 * Usage      : Exécuter le script et saisir deux nombres flottants
 ******************************************************************************/
"""

try:
    # Si une erreur se produit dans ce bloc, Python passera dans le except

    # Demande a l'utilisateur de saisir un premier nombre flottant
    a = float(input("Entrez le premier nombre : "))

    # Demande a l'utilisateur de saisir un deuxieme nombre flottant
    b = float(input("Entrez le deuxieme nombre : "))

    # Multiplication des deux nombres saisis
    resultat = a * b

    # Initialisation de l'exposant a 0
    # Il servira a memoriser le nombre de decalages effectues
    expo = 0

    # Verification que le resultat n'est pas nul
    if resultat != 0:

        # Tant que la valeur absolue du resultat est superieure ou egale a 10
        while abs(resultat) >= 10:

            # On divise le resultat par 10
            resultat = resultat / 10

            # On augmente l'exposant de 1
            expo = expo + 1

        # Tant que la valeur absolue du resultat est inferieure a 1
        while abs(resultat) < 1:

            # On multiplie le resultat par 10
            resultat = resultat * 10

            # On diminue l'exposant de 1
            expo = expo - 1

    # Affichage de la mantisse normalisee
    print("Resultat normalise :", resultat)

    # Affichage de l'exposant calcule
    print("Exposant :", expo)

    # Affichage du resultat complet sous forme scientifique
    print("Resultat en notation scientifique :", str(resultat) + " x 10^" + str(expo))

# Gestion de l'erreur si l'utilisateur n'entre pas un nombre valide
except ValueError:

    # Message d'erreur affiche a l'utilisateur
    print("Erreur : veuillez entrer des nombres valides.")