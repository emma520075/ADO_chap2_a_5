"""
/******************************************************************************
 * Nom        : Chap_4_ex_4.17.py
 * Rôle       : Multiplie deux nombres flottants et affiche le résultat 
 *              normalisé en notation scientifique
 * Auteur     : Emma BARETS
 * Version    : Version final du 03/02/2026
 * Licence    : Réalisé dans le cadre du Architecture des ordinateurs
 * Dépendances : Aucun
 * Usage      : Exécuter le script et saisir deux nombres flottants
 ******************************************************************************/
"""

try:
    # Entrer la valeur de x
    x = float(input("Entrez la valeur de x : "))

    # Entrer le nombre de termes n
    n = int(input("Entrez le nombre de termes pour l'approximation : "))

    # Verification que n est positif
    if n < 0:
        print("Erreur : le nombre de termes doit etre positif.")
    else:

        # Initialisation de la somme avec le premier terme
        exp = 1.0

        # Variables utilisees pour calculer les termes successifs
        fact = 1
        puissance = 1

        # Calcul de la serie de Taylor
        for i in range(1, n + 1):
            puissance = puissance * x
            fact = fact * i
            terme = puissance / fact
            exp = exp + terme

        # Affichage du resultat
        print("Approximation de e^", x, "avec", n, "termes :", exp)

except ValueError:
    print("Erreur : veuillez entrer des valeurs numeriques valides.")